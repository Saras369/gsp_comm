package com.example.gujarati_samaj_paris

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
