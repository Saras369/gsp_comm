import 'app_localizations.dart';

/// The translations for French (`fr`).
class AppLocalizationsFr extends AppLocalizations {
  AppLocalizationsFr([String locale = 'fr']) : super(locale);

  @override
  String get language => 'Français';

  @override
  String get chooseLanguage => 'Choisissez votre langue';

  @override
  String get continueInEnglish => 'Continuer en français';

  @override
  String get enterEmail => 'Entrer votre Email';

  @override
  String get enterPassword => 'Entrer le mot de passe';

  @override
  String get confirmPassword => 'Confirmez le mot de passe';

  @override
  String get login => 'Connexion';

  @override
  String get dontHaveAnAccount => 'Vous n\'avez pas de compte ?';
}
