import 'package:flutter/material.dart';

import '../widgets/home_post_card.dart';

class FeedScreen extends StatelessWidget {
  const FeedScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(children: const [
          // AppBarWidget(text: 'IGCA-Paris'),
          SizedBox(
            height: 30,
          ),
          HomePostCard(
            profilePicUrl:
                'https://media.istockphoto.com/id/953079238/photo/smiling-man-with-hat-and-sunglasses.webp?b=1&s=170667a&w=0&k=20&c=vQfZPBTgg9PpwktCJ6Wqi5F2CPQ9hj9q9Q5bXiGnjxo=',
            userPostUrl:
                'https://images.unsplash.com/photo-1608725131946-c73a151f2f8a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTF8fGluc3RhZ3JhbSUyMHBvc3R8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
            userName: 'Rahul',
          ),
          HomePostCard(
              profilePicUrl:
                  'https://media.istockphoto.com/id/477555600/photo/beach-woman.webp?b=1&s=170667a&w=0&k=20&c=nQc2moy1BUUrKhVeVEXbY8esQJQH3qlIHSe4mfX0qFo=',
              userPostUrl:
                  'https://images.unsplash.com/photo-1687360441205-807780a8e5db?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHw2fHx8ZW58MHx8fHx8&auto=format&fit=crop&w=500&q=60',
              userName: 'Salena'),
          HomePostCard(
              profilePicUrl:
                  'https://media.istockphoto.com/id/1369508923/photo/mixed-race-young-woman-using-smartphone-isolated-on-grey-wall.webp?b=1&s=170667a&w=0&k=20&c=7YJ0ytza4_4fsu-ALAzyEG-RV_nXMpohVaBJbXsANno=',
              userPostUrl:
                  'https://media.istockphoto.com/id/1286034588/photo/hand-of-an-anonymous-young-woman-taking-a-snapshot-of-her-delicious-looking-pumpkin-spice.webp?b=1&s=170667a&w=0&k=20&c=KEP_pzhyvDgXj-X9KTm3Rf___jqSd00Wes_ZEmiTHx8=',
              userName: 'Parikshit'),
          HomePostCard(
            profilePicUrl:
                'https://media.istockphoto.com/id/953079238/photo/smiling-man-with-hat-and-sunglasses.webp?b=1&s=170667a&w=0&k=20&c=vQfZPBTgg9PpwktCJ6Wqi5F2CPQ9hj9q9Q5bXiGnjxo=',
            userPostUrl:
                'https://images.unsplash.com/photo-1608725131946-c73a151f2f8a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTF8fGluc3RhZ3JhbSUyMHBvc3R8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60',
            userName: 'Rahul',
          ),
        ]),
      ),
    );
  }
}
