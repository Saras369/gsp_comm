
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:gujarati_samaj_paris/model/bhajan_model.dart';
import 'package:gujarati_samaj_paris/repository/bhajan_repo.dart';

import '../data/response/api_response.dart';

class BhajanViewModel with ChangeNotifier {

  final _myRepo = BhajanRepo();

  ApiResponse<BhajanModel> bhajanList = ApiResponse.loading();

  setBhajan(ApiResponse<BhajanModel> response) {
    bhajanList = response;
    notifyListeners();
  }



  Future<void> fetchBhajanAPi() async {
    setBhajan(ApiResponse.loading());
    await _myRepo.bhajanAPi().then((value) {
      log("success bhajan");
      setBhajan(ApiResponse.completed(value));
    }).onError((error, stackTrace) {
      setBhajan(ApiResponse.error(error.toString()));
      log(error.toString());
    });
  }

}