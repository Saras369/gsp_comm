

import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:gujarati_samaj_paris/model/paid_program_model.dart';
import 'package:gujarati_samaj_paris/repository/paid_program_repo.dart';

import '../data/response/api_response.dart';

class PaidProgramViewModel with ChangeNotifier {

  final _myRepo = PaidProgramRepo();

  ApiResponse<PaidProgramModel> paidProgramList = ApiResponse.loading();

  setpaidProgram(ApiResponse<PaidProgramModel> response) {
    paidProgramList = response;
    notifyListeners();
  }



  Future<void> fetchpaidProgramAPi() async {
    setpaidProgram(ApiResponse.loading());
    await _myRepo.padProgramAPi().then((value) {
      log("success bhajan");
      setpaidProgram(ApiResponse.completed(value));
    }).onError((error, stackTrace) {
      setpaidProgram(ApiResponse.error(error.toString()));
      log(error.toString());
    });
  }


}