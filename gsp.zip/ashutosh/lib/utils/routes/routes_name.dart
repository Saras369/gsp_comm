

class RoutesName {
  static const String splashScreen = 'splashScreen';
  static const String selectLanguageScreen = 'selectLanguageScreen';
  static const String loginScreen = 'loginScreen';
  static const String signupScreen = 'signupScreen';
  static const String homeScreenLayout = 'homeScreenLayout';
  static const String myIdCard = 'myIdCard';
  static const String eventScreen = 'eventScreen';
  static const String myEventScreen = 'myEventScreen';
  static const String createEventScreen = 'createEventScreen';
  static const String previewArticle = 'previewArticle';
  static const String homeScreen = 'homeScreen';
  static const String feedScreen = 'feedScreen';
  static const String photosVideosScreen = 'photosVideosScreen';
  static const String feesDonationScreen = 'feesDonationScreen';
  static const String liveClassScreen = 'liveClassScreen';
  static const String paidProgramsScreen = 'paidProgramsScreen';
  static const String vendorListingScreen = 'vendorListingScreen';
  static const String bhajanMusicScreen = 'bhajanMusicScreen';
  static const String helpfulLinkScreen = 'helpfulLinkScreen';
  static const String conversationScreen = 'conversationScreen';

}