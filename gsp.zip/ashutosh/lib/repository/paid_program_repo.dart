
import 'package:gujarati_samaj_paris/model/paid_program_model.dart';

import '../data/network/base_api_services.dart';
import '../data/network/network_api_service.dart';
import '../utils/app_url.dart';

class PaidProgramRepo{
  final BaseApiServices _apiServices = NetworkApiService();

  Future<dynamic> padProgramAPi() async {
    try {
      dynamic response =
      await _apiServices.getGetApiResponse(AppUrl.paidProgramEndPoint);
      return response = PaidProgramModel.fromJson(response);
    } catch (e) {
      rethrow;
    }
  }

}