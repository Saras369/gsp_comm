
import 'package:gujarati_samaj_paris/model/bhajan_model.dart';

import '../data/network/base_api_services.dart';
import '../data/network/network_api_service.dart';
import '../utils/app_url.dart';

class BhajanRepo {
  final BaseApiServices _apiServices = NetworkApiService();

  Future<dynamic> bhajanAPi() async {
    try {
      dynamic response =
      await _apiServices.getGetApiResponse(AppUrl.bhajanEndPoint);
      return response = BhajanModel.fromJson(response);
    } catch (e) {
      rethrow;
    }
  }

}